var app = require('scripts/app');

app.renderUI()